/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prog5121part2;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author USER
 */
public class PROG5121Part2 {

package com.mycompany.prog5121part1;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Scanner;

public class PROG5121Part1 {

    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    ArrayList<Login>users = new ArrayList<>(); //store a number of users
   
    System.out.println("\n welcome to our chat app 2026 select options below:");
    
    while(true){
        //display menu after each action
        System.out.println("\nMain Menu:");
        System.out.println("1. Register");
        System.out.println("2. Login");
        System.out.println("3. Exit");
        System.out.println("Choose an option:");
        
        int choice = scanner.nextInt();
        scanner.nextLine(); //consume newline
                
        switch(choice){
            case 1: // Registration
                System.out.print("Enter username");
                String username = scanner.nextLine();
                System.out.println("Username successfully captured:");
                //validation of username
                boolean validUsername = username.contains("_")&&username.length()<=5;
                if(!validUsername){
                    System.out.println("Username must contain t least one underscore(_) and no longer than 5 characters long.");
                    break;
                }
                System.out.print("enter password:");
                String password = scanner.nextLine();
                System.out.println("password successfully captured!");
                //validat password
                boolean validatPassword =password.length()>8 && password.matches(".*[A-Z].*") && password.matches(".*\\d.*")&&
                        password.matches(".*[!@#$%^&*(),.?\":{}|<>].*");
                if(!validatPassword){
                    System.out.println("password must be at least 8 characters long, contain an uppercase letter, number and special characters");
                    break;
                }
                System.out.print(" Enter a SA phone number: {e.g +27831111111}:");
                String phoneNumber = scanner.nextLine();
                System.out.println("Cellphone number is successfully addes!");
                //validate phone
                String regex ="\\+27[6-8]\\{8}";
                if (phoneNumber.matches(regex)){
                    System.out.println("invalid phone number format! use +27xxxxxxxxx");
                    break;
                }
                //check if the user already exists
                boolean userExists = users.stream().anyMatch (u ->u.getUsernarme().equals(username));
                if(userExists){
                    System.out.println("Username already exists. please choose another username.");
                    break;
                }
                //add the new user
                users.add(new Login(username, password, phoneNumber));
                System.out.println("user Registered successfully!");
                //welcome the user and transition to login
                System.out.println("welcome"+ username + "you can now log in");
                System.out.println("Redirecting you to login page.....\n");
                
                //imediately prompt the user to login
                promptLogin(scanner, users);
                break;
                
            case 2: //login
                if(users.isEmpty()){
                    System.out.println("No users are registered yet. Please register first.");
                    break;
                }
                //prompt the user to login
                promptlogin(scanner,users);
                break;
            
            case 3: //Exit
                System.out.println("Goodbye!!");
                scanner.close();
                return;
                
            default: 
                System.out.println("invalid option. Please choose 1,2 or 3");
            }
        }
    }
    //method to handle login logic
    private static void promptLogin(Scanner scanner,ArrayList<Login>users){
        System.out.print("Enter username:");
        String enteredUsername = scanner.nextLine();
        
        System.out.print("Enter password:");
        String enteredPassword = scanner.nextLine();
        
       Login foundUser = null;

    // SIMPLE LOOP (better for beginners)
    for (Login u : users) {
    if (u.getUsername().equals(enteredUsername)) {
    foundUser = u;
    break;
    }
}

    if (foundUser != null && foundUser.loginUser(enteredPassword)) {
    System.out.println("Login successful! Welcome " + enteredUsername);
    } else {
    System.out.println("Login failed. Incorrect details.");
    }
   
    }
}

    }
}
